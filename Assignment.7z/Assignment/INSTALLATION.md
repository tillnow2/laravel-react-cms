# INSTALLATION GUIDE

## Laravel CMS - Complete Installation Instructions

This guide will help you set up the Laravel 12 + React CMS project from scratch.

---

## Prerequisites Checklist

Before starting, ensure you have:

- [ ] PHP 8.2 or higher
- [ ] Composer (latest version)
- [ ] Node.js 16+ and npm
- [ ] MySQL 5.7+ or PostgreSQL 12+
- [ ] Git (optional, for version control)

### Check Your System

```bash
# Check PHP version
php --version

# Check Composer
composer --version

# Check Node.js and npm
node --version
npm --version
```

---

## Step-by-Step Installation

### 1. Database Setup

**For MySQL:**
```bash
# Login to MySQL
mysql -u root -p

# Create database
CREATE DATABASE laravel_cms;
exit;
```

**For PostgreSQL:**
```bash
# Login to PostgreSQL
psql -U postgres

# Create database
CREATE DATABASE laravel_cms;
\q
```

---

### 2. Backend Installation (Laravel)

```bash
# Navigate to the backend directory
cd C:\Users\16244\Documents\Assignment\backend

# Install PHP dependencies
composer install

# Copy environment file
copy .env.example .env

# Generate application key
php artisan key:generate
```

**Edit `.env` file** with your database credentials:
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=laravel_cms
DB_USERNAME=root
DB_PASSWORD=your_password_here

# For CORS - React admin URL
SANCTUM_STATEFUL_DOMAINS=localhost,localhost:3000,127.0.0.1,127.0.0.1:3000
```

**Run migrations and seed data:**
```bash
# Run database migrations
php artisan migrate

# Seed database with default users
php artisan db:seed

# Create symbolic link for storage
php artisan storage:link
```

**Start Laravel server:**
```bash
php artisan serve
```

✅ Backend should now be running at: **http://localhost:8000**

---

### 3. Frontend Installation (React Admin)

Open a **NEW terminal window** (keep Laravel server running):

```bash
# Navigate to admin directory
cd C:\Users\16244\Documents\Assignment\admin

# Install Node.js dependencies
npm install

# Start React development server
npm start
```

✅ Admin panel should now be running at: **http://localhost:3000**

---

## Testing the Installation

### 1. Test Backend API

Open browser or Postman:
- URL: http://localhost:8000/api/login
- Method: POST
- Body (JSON):
```json
{
  "email": "admin@example.com",
  "password": "password"
}
```

### 2. Test Admin Panel

1. Open http://localhost:3000 in your browser
2. Login with:
   - **Email:** admin@example.com
   - **Password:** password
3. You should see the dashboard

### 3. Test Public Website

1. Open http://localhost:8000 in your browser
2. You should see the homepage
3. Navigate to http://localhost:8000/blog

---

## Default Users

After seeding, you'll have these users:

**Admin User:**
- Email: `admin@example.com`
- Password: `password`
- Admin: Yes

**Regular User:**
- Email: `user@example.com`
- Password: `password`
- Admin: No

---

## Common Issues & Solutions

### Issue 1: "Composer not found"
**Solution:** Install Composer from https://getcomposer.org/

### Issue 2: "PHP version too old"
**Solution:** Install PHP 8.2+ from https://windows.php.net/download/

### Issue 3: "npm not found"
**Solution:** Install Node.js from https://nodejs.org/

### Issue 4: "Database connection failed"
**Solution:** 
- Check MySQL/PostgreSQL is running
- Verify credentials in `.env` file
- Ensure database exists

### Issue 5: "CORS error in admin panel"
**Solution:**
- Check `SANCTUM_STATEFUL_DOMAINS` in `.env`
- Verify `config/cors.php` includes `http://localhost:3000`
- Run: `php artisan config:clear`

### Issue 6: "Storage link already exists"
**Solution:** This is normal if you already created it. Ignore the message.

### Issue 7: "Port already in use"
**Solution:**
- For Laravel: `php artisan serve --port=8001`
- For React: Set PORT environment variable or kill process on port 3000

---

## Quick Start Commands

**Start Both Servers:**

Terminal 1 (Backend):
```bash
cd C:\Users\16244\Documents\Assignment\backend
php artisan serve
```

Terminal 2 (Frontend):
```bash
cd C:\Users\16244\Documents\Assignment\admin
npm start
```

---

## File Permissions (Linux/Mac)

If you're on Linux or Mac:
```bash
cd backend
chmod -R 775 storage
chmod -R 775 bootstrap/cache
```

---

## Alternative: Using SQL Dump

If migrations fail, use the SQL dump:

```bash
# MySQL
mysql -u root -p laravel_cms < database.sql

# PostgreSQL
psql -U postgres laravel_cms < database.sql
```

---

## Next Steps

1. ✅ Login to admin panel
2. ✅ Create your first post
3. ✅ Upload media files
4. ✅ Create static pages
5. ✅ View public website
6. ✅ Customize as needed

---

## Production Deployment

For production deployment:

**Backend:**
```bash
composer install --optimize-autoloader --no-dev
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

**Frontend:**
```bash
npm run build
# Deploy 'build' folder to your web server
```

---

## Support

If you encounter any issues:
1. Check Laravel logs: `storage/logs/laravel.log`
2. Check browser console for JavaScript errors
3. Verify all services are running
4. Clear cache: `php artisan cache:clear`

---

**Congratulations! Your Laravel CMS is now ready to use! 🎉**
