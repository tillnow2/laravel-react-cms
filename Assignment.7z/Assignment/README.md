# Laravel 12 + React CMS

A modern, full-featured Content Management System built with Laravel 12 (backend & public website) and React 18 (admin panel).

## 📋 Features

### Backend (Laravel 12)
- ✅ RESTful API with Laravel Sanctum authentication
- ✅ Models: User, Post, Page, Category, Media
- ✅ Form Request validation
- ✅ API Resources for JSON transformation
- ✅ Automatic slug generation for SEO
- ✅ File upload handling with storage management
- ✅ Database migrations and seeders
- ✅ CORS configuration for API access

### Admin Panel (React 18)
- ✅ User authentication with JWT tokens
- ✅ Dashboard with content statistics
- ✅ Posts CRUD (Create, Read, Update, Delete)
- ✅ Pages CRUD
- ✅ Media library with upload functionality
- ✅ WYSIWYG editor (React Quill)
- ✅ Publish/unpublish toggle
- ✅ Protected routes
- ✅ Responsive design

### Public Website (Blade Templates)
- ✅ Home page with latest posts
- ✅ Blog listing with pagination
- ✅ Blog detail page with related posts
- ✅ Dynamic pages with custom slugs
- ✅ SEO-friendly meta tags
- ✅ Responsive layout

## 🛠️ Technology Stack

- **Backend**: Laravel 12, PHP 8.2+
- **Frontend Admin**: React 18, React Router, Axios
- **Database**: MySQL/PostgreSQL
- **Authentication**: Laravel Sanctum
- **Editor**: React Quill (WYSIWYG)
- **Styling**: Custom CSS

## 📁 Project Structure

```
Assignment/
├── backend/           # Laravel 12 application
│   ├── app/
│   │   ├── Http/
│   │   │   ├── Controllers/
│   │   │   │   ├── Api/
│   │   │   │   └── WebController.php
│   │   │   ├── Requests/
│   │   │   └── Resources/
│   │   └── Models/
│   ├── database/
│   │   ├── migrations/
│   │   └── seeders/
│   ├── resources/
│   │   └── views/
│   ├── routes/
│   │   ├── api.php
│   │   └── web.php
│   └── storage/
│
└── admin/            # React admin panel
    ├── public/
    ├── src/
    │   ├── components/
    │   ├── context/
    │   ├── pages/
    │   ├── services/
    │   ├── App.js
    │   └── index.js
    └── package.json
```

## 🚀 Setup Instructions

### Prerequisites

- PHP 8.2 or higher
- Composer
- Node.js 16+ and npm
- MySQL or PostgreSQL
- Git

### Backend Setup (Laravel)

1. **Navigate to the backend directory**
   ```bash
   cd backend
   ```

2. **Install PHP dependencies**
   ```bash
   composer install
   ```

3. **Configure environment**
   ```bash
   cp .env.example .env
   ```

4. **Update .env file with your database credentials**
   ```env
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=laravel_cms
   DB_USERNAME=root
   DB_PASSWORD=your_password
   ```

5. **Generate application key**
   ```bash
   php artisan key:generate
   ```

6. **Run migrations**
   ```bash
   php artisan migrate
   ```

7. **Seed the database (creates admin user)**
   ```bash
   php artisan db:seed
   ```
   Default credentials:
   - Email: `admin@example.com`
   - Password: `password`

8. **Create storage symlink**
   ```bash
   php artisan storage:link
   ```

9. **Start the development server**
   ```bash
   php artisan serve
   ```
   Backend will run at: http://localhost:8000

### Frontend Admin Setup (React)

1. **Navigate to the admin directory**
   ```bash
   cd admin
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm start
   ```
   Admin panel will run at: http://localhost:3000

## 🔑 Default Credentials

**Admin User:**
- Email: `admin@example.com`
- Password: `password`

**Regular User:**
- Email: `user@example.com`
- Password: `password`

## 📡 API Endpoints

### Authentication
- `POST /api/login` - Login
- `POST /api/logout` - Logout (authenticated)
- `GET /api/me` - Get authenticated user

### Posts
- `GET /api/posts` - List all posts
- `POST /api/posts` - Create new post
- `GET /api/posts/{id}` - Get single post
- `PUT /api/posts/{id}` - Update post
- `DELETE /api/posts/{id}` - Delete post
- `PATCH /api/posts/{id}/publish` - Toggle publish status

### Pages
- `GET /api/pages` - List all pages
- `POST /api/pages` - Create new page
- `GET /api/pages/{id}` - Get single page
- `PUT /api/pages/{id}` - Update page
- `DELETE /api/pages/{id}` - Delete page
- `PATCH /api/pages/{id}/publish` - Toggle publish status

### Media
- `GET /api/media` - List all media
- `POST /api/media/upload` - Upload file
- `DELETE /api/media/{id}` - Delete media

### Dashboard
- `GET /api/dashboard/stats` - Get statistics

## 🌐 Public Routes

- `/` - Home page
- `/blog` - Blog listing
- `/blog/{slug}` - Blog post detail
- `/{slug}` - Dynamic page

## 📝 Usage Guide

### Creating a Post

1. Login to admin panel at http://localhost:3000
2. Navigate to "Posts" in sidebar
3. Click "+ New Post"
4. Fill in the form:
   - Title (required)
   - Slug (auto-generated if empty)
   - Excerpt (optional)
   - Content (required, WYSIWYG editor)
   - Featured Image URL
   - Category ID
   - Publish checkbox
5. Click "Create Post"

### Creating a Page

1. Navigate to "Pages" in admin panel
2. Click "+ New Page"
3. Fill in:
   - Title (required)
   - Slug (auto-generated if empty)
   - Content (required)
   - Template selection
   - Publish checkbox
4. Click "Create Page"

### Uploading Media

1. Navigate to "Media" in admin panel
2. Click "+ Upload File"
3. Select file (images, PDF, documents, ZIP)
4. File will be uploaded and displayed in library

## 🔒 Security Features

- Laravel Sanctum for API authentication
- CSRF protection
- Password hashing with bcrypt
- Form request validation
- Protected routes in React
- File upload validation

## 🎨 Customization

### Adding New Models

1. Create migration: `php artisan make:migration create_table_name`
2. Create model: `php artisan make:model ModelName`
3. Create controller: `php artisan make:controller Api/ModelController --api`
4. Create form request: `php artisan make:request ModelRequest`
5. Create resource: `php artisan make:resource ModelResource`
6. Add routes in `routes/api.php`

### Customizing Blade Templates

Templates are located in `resources/views/`:
- `layouts/app.blade.php` - Main layout
- `home.blade.php` - Homepage
- `blog.blade.php` - Blog listing
- `post.blade.php` - Single post
- `page.blade.php` - Dynamic pages

## 🧪 Testing

### Backend Testing
```bash
cd backend
php artisan test
```

### Frontend Testing
```bash
cd admin
npm test
```

## 📦 Production Build

### Backend
```bash
cd backend
composer install --optimize-autoloader --no-dev
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

### Frontend
```bash
cd admin
npm run build
```

## 🐛 Troubleshooting

### CORS Issues
Ensure `config/cors.php` includes your frontend URL:
```php
'allowed_origins' => ['http://localhost:3000'],
```

### Storage Issues
If images don't show:
```bash
php artisan storage:link
```

### Permission Issues
```bash
chmod -R 775 storage bootstrap/cache
```

## 📄 License

This project is open-source and available under the MIT License.

## 👤 Author

Created for Laravel + React CMS Assignment

## 🙏 Acknowledgments

- Laravel Framework
- React
- React Router
- React Quill
- Axios

## 📞 Support

For issues and questions, please create an issue in the repository.

---

**Note**: This is a demo project. For production use, please implement additional security measures, error handling, and testing.
