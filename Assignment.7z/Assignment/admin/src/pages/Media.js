import React, { useEffect, useState } from 'react';
import api from '../services/api';
import './Media.css';

const Media = () => {
  const [media, setMedia] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchMedia();
  }, []);

  const fetchMedia = async () => {
    try {
      const response = await api.get('/media', { params: { per_page: 50 } });
      setMedia(response.data.data);
    } catch (error) {
      console.error('Failed to fetch media:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await api.post('/media/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setMedia([response.data.data, ...media]);
      alert('File uploaded successfully!');
    } catch (error) {
      console.error('Failed to upload file:', error);
      alert('Failed to upload file: ' + (error.response?.data?.message || error.message));
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleDelete = async (id, filePath) => {
    if (!window.confirm('Are you sure you want to delete this file?')) return;

    try {
      await api.delete(`/media/${id}`);
      setMedia(media.filter((item) => item.id !== id));
    } catch (error) {
      console.error('Failed to delete media:', error);
      alert('Failed to delete media');
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  const isImage = (mimeType) => {
    return mimeType && mimeType.startsWith('image/');
  };

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="media-page">
      <div className="page-header">
        <h2>Media Library</h2>
        <label className="btn btn-primary" style={{ cursor: 'pointer' }}>
          {uploading ? 'Uploading...' : '+ Upload File'}
          <input
            type="file"
            onChange={handleUpload}
            disabled={uploading}
            style={{ display: 'none' }}
            accept="image/*,.pdf,.doc,.docx,.zip"
          />
        </label>
      </div>

      {media.length === 0 ? (
        <div className="empty-state">
          <p>No media files yet. Upload your first file!</p>
        </div>
      ) : (
        <div className="media-grid">
          {media.map((item) => (
            <div key={item.id} className="media-item">
              <div className="media-preview">
                {isImage(item.mime_type) ? (
                  <img src={item.url} alt={item.file_name} />
                ) : (
                  <div className="file-icon">
                    📄
                  </div>
                )}
              </div>
              <div className="media-info">
                <p className="media-name" title={item.file_name}>
                  {item.file_name}
                </p>
                <p className="media-size">{formatFileSize(item.file_size)}</p>
                <p className="media-date">
                  {new Date(item.created_at).toLocaleDateString()}
                </p>
              </div>
              <div className="media-actions">
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-action btn-view"
                >
                  View
                </a>
                <button
                  onClick={() => handleDelete(item.id, item.file_path)}
                  className="btn-action btn-delete"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Media;
