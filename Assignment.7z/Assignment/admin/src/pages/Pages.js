import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import './Pages.css';

const Pages = () => {
  const [pages, setPages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPages();
  }, []);

  const fetchPages = async () => {
    try {
      const response = await api.get('/pages', { params: { per_page: 50 } });
      setPages(response.data.data);
    } catch (error) {
      console.error('Failed to fetch pages:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this page?')) return;

    try {
      await api.delete(`/pages/${id}`);
      setPages(pages.filter((page) => page.id !== id));
    } catch (error) {
      console.error('Failed to delete page:', error);
      alert('Failed to delete page');
    }
  };

  const handleTogglePublish = async (page) => {
    try {
      const response = await api.patch(`/pages/${page.id}/publish`, {
        is_published: !page.is_published
      });
      setPages(pages.map((p) => (p.id === page.id ? response.data.data : p)));
    } catch (error) {
      console.error('Failed to toggle publish:', error);
      alert('Failed to update page status');
    }
  };

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="pages-page">
      <div className="page-header">
        <h2>Pages</h2>
        <Link to="/pages/create" className="btn btn-primary">
          + New Page
        </Link>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Title</th>
              <th>Slug</th>
              <th>Author</th>
              <th>Status</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {pages.length === 0 ? (
              <tr>
                <td colSpan="6" style={{ textAlign: 'center', padding: '2rem' }}>
                  No pages found. <Link to="/pages/create">Create one</Link>
                </td>
              </tr>
            ) : (
              pages.map((page) => (
                <tr key={page.id}>
                  <td>
                    <strong>{page.title}</strong>
                  </td>
                  <td>/{page.slug}</td>
                  <td>{page.user?.name}</td>
                  <td>
                    <button
                      onClick={() => handleTogglePublish(page)}
                      className={`badge ${page.is_published ? 'badge-success' : 'badge-warning'}`}
                      style={{ cursor: 'pointer', border: 'none' }}
                    >
                      {page.is_published ? 'Published' : 'Draft'}
                    </button>
                  </td>
                  <td>{new Date(page.created_at).toLocaleDateString()}</td>
                  <td>
                    <div className="action-buttons">
                      <Link to={`/pages/edit/${page.id}`} className="btn-action btn-edit">
                        Edit
                      </Link>
                      <button
                        onClick={() => handleDelete(page.id)}
                        className="btn-action btn-delete"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Pages;
