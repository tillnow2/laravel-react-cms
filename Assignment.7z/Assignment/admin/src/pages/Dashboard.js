import React, { useEffect, useState } from 'react';
import api from '../services/api';
import './Dashboard.css';

const Dashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await api.get('/dashboard/stats');
      setStats(response.data);
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <div className="dashboard">
      <h2>Dashboard</h2>
      
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon" style={{ background: '#dbeafe' }}>📝</div>
          <div className="stat-content">
            <h3>Total Posts</h3>
            <p className="stat-number">{stats?.total_posts || 0}</p>
            <p className="stat-detail">
              {stats?.published_posts || 0} published, {stats?.draft_posts || 0} drafts
            </p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon" style={{ background: '#dcfce7' }}>📄</div>
          <div className="stat-content">
            <h3>Total Pages</h3>
            <p className="stat-number">{stats?.total_pages || 0}</p>
            <p className="stat-detail">
              {stats?.published_pages || 0} published, {stats?.draft_pages || 0} drafts
            </p>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon" style={{ background: '#fef3c7' }}>🖼️</div>
          <div className="stat-content">
            <h3>Media Files</h3>
            <p className="stat-number">{stats?.total_media || 0}</p>
            <p className="stat-detail">Images, documents, etc.</p>
          </div>
        </div>
      </div>

      {stats?.recent_posts && stats.recent_posts.length > 0 && (
        <div className="recent-posts">
          <h3>Recent Posts</h3>
          <div className="posts-table">
            <table>
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Author</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {stats.recent_posts.map((post) => (
                  <tr key={post.id}>
                    <td>{post.title}</td>
                    <td>{post.user?.name}</td>
                    <td>
                      <span className={`badge ${post.is_published ? 'badge-success' : 'badge-warning'}`}>
                        {post.is_published ? 'Published' : 'Draft'}
                      </span>
                    </td>
                    <td>{new Date(post.created_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
