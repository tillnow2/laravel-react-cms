import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Layout.css';

const Layout = ({ children }) => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const isActive = (path) => {
    return location.pathname === path || location.pathname.startsWith(path + '/');
  };

  return (
    <div className="layout">
      <aside className="sidebar">
        <div className="sidebar-header">
          <h2>Laravel CMS</h2>
        </div>
        <nav className="sidebar-nav">
          <Link to="/" className={isActive('/') && location.pathname === '/' ? 'active' : ''}>
            <span className="icon">📊</span>
            Dashboard
          </Link>
          <Link to="/posts" className={isActive('/posts') ? 'active' : ''}>
            <span className="icon">📝</span>
            Posts
          </Link>
          <Link to="/pages" className={isActive('/pages') ? 'active' : ''}>
            <span className="icon">📄</span>
            Pages
          </Link>
          <Link to="/media" className={isActive('/media') ? 'active' : ''}>
            <span className="icon">🖼️</span>
            Media
          </Link>
        </nav>
      </aside>
      
      <div className="main-content">
        <header className="header">
          <div className="header-content">
            <h1>Admin Panel</h1>
            <div className="user-menu">
              <span>{user?.name}</span>
              <button onClick={handleLogout} className="btn-logout">
                Logout
              </button>
            </div>
          </div>
        </header>
        
        <main className="content">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
