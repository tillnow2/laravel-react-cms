# Laravel CMS Admin Panel

React 18 admin panel for managing CMS content.

## Installation

1. Install dependencies:
```bash
npm install
```

2. Start development server:
```bash
npm start
```

The app will run at http://localhost:3000

## Build for Production

```bash
npm run build
```

## Features

- Dashboard with statistics
- Posts management (CRUD)
- Pages management (CRUD)
- Media library with upload
- WYSIWYG content editor
- Authentication
- Responsive design

## Login

Default credentials:
- Email: admin@example.com
- Password: password

## Environment

The app connects to Laravel API at `http://localhost:8000/api` (configured in package.json proxy).

## Tech Stack

- React 18
- React Router DOM
- Axios
- React Quill (WYSIWYG)
- Context API for state management
