@extends('layouts.app')

@section('title', 'Blog - Laravel CMS')

@section('content')
    <h1 style="font-size: 2.5rem; margin-bottom: 2rem;">Blog</h1>

    <div style="margin-bottom: 2rem;">
        <form method="GET" action="{{ route('blog') }}" style="display: flex; gap: 1rem;">
            <input type="text" name="search" placeholder="Search posts..." value="{{ request('search') }}" 
                   style="flex: 1; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 0.375rem; font-size: 1rem;">
            <button type="submit" class="btn">Search</button>
        </form>
    </div>

    @if($posts->count() > 0)
        <div class="grid">
            @foreach($posts as $post)
                <article class="card">
                    @if($post->featured_image)
                        <img src="{{ asset('storage/' . $post->featured_image) }}" alt="{{ $post->title }}">
                    @else
                        <img src="https://via.placeholder.com/400x200?text={{ urlencode($post->title) }}" alt="{{ $post->title }}">
                    @endif
                    <div class="card-body">
                        <h2 class="card-title">
                            <a href="{{ route('post', $post->slug) }}">{{ $post->title }}</a>
                        </h2>
                        @if($post->excerpt)
                            <p>{{ Str::limit($post->excerpt, 150) }}</p>
                        @endif
                        <div class="meta">
                            <span>By {{ $post->user->name }}</span>
                            @if($post->category)
                                <span> • {{ $post->category->name }}</span>
                            @endif
                            <span> • {{ $post->published_at->format('M d, Y') }}</span>
                        </div>
                    </div>
                </article>
            @endforeach
        </div>

        <div style="margin-top: 3rem; display: flex; justify-content: center;">
            {{ $posts->links() }}
        </div>
    @else
        <p style="text-align: center; color: #6b7280; margin-top: 3rem;">No posts found.</p>
    @endif
@endsection
