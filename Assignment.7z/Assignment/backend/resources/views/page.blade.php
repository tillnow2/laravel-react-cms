@extends('layouts.app')

@section('title', $page->title . ' - Laravel CMS')

@section('content')
    <article style="max-width: 900px; margin: 0 auto;">
        <header style="margin-bottom: 2rem;">
            <h1 style="font-size: 2.5rem; margin-bottom: 1rem;">{{ $page->title }}</h1>
        </header>

        <div class="content" style="background: #fff; padding: 3rem; border-radius: 0.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            {!! $page->content !!}
        </div>
    </article>
@endsection
