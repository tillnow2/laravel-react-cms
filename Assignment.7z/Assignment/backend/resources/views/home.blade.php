@extends('layouts.app')

@section('title', 'Home - Laravel CMS')

@section('content')
    <div class="hero">
        <h1>Welcome to Laravel CMS</h1>
        <p>A modern, flexible content management system built with Laravel 12</p>
        <a href="{{ route('blog') }}" class="btn">Explore Blog</a>
    </div>

    <h2 style="margin-bottom: 1rem; font-size: 2rem;">Latest Posts</h2>

    @if($posts->count() > 0)
        <div class="grid">
            @foreach($posts as $post)
                <article class="card">
                    @if($post->featured_image)
                        <img src="{{ asset('storage/' . $post->featured_image) }}" alt="{{ $post->title }}">
                    @else
                        <img src="https://via.placeholder.com/400x200?text={{ urlencode($post->title) }}" alt="{{ $post->title }}">
                    @endif
                    <div class="card-body">
                        <h3 class="card-title">
                            <a href="{{ route('post', $post->slug) }}">{{ $post->title }}</a>
                        </h3>
                        @if($post->excerpt)
                            <p>{{ Str::limit($post->excerpt, 150) }}</p>
                        @endif
                        <div class="meta">
                            <span>By {{ $post->user->name }}</span>
                            @if($post->category)
                                <span> • {{ $post->category->name }}</span>
                            @endif
                            <span> • {{ $post->published_at->format('M d, Y') }}</span>
                        </div>
                    </div>
                </article>
            @endforeach
        </div>
    @else
        <p style="text-align: center; color: #6b7280; margin-top: 3rem;">No posts available yet.</p>
    @endif
@endsection
