@extends('layouts.app')

@section('title', $post->title . ' - Laravel CMS')
@section('description', $post->excerpt ?? Str::limit(strip_tags($post->content), 160))

@section('content')
    <article style="max-width: 800px; margin: 0 auto;">
        <header style="margin-bottom: 2rem;">
            <h1 style="font-size: 2.5rem; margin-bottom: 1rem;">{{ $post->title }}</h1>
            <div class="meta" style="font-size: 1rem;">
                <span>By {{ $post->user->name }}</span>
                @if($post->category)
                    <span> • <a href="{{ route('blog') }}?category={{ $post->category->id }}" style="color: #2563eb; text-decoration: none;">{{ $post->category->name }}</a></span>
                @endif
                <span> • {{ $post->published_at->format('F d, Y') }}</span>
            </div>
        </header>

        @if($post->featured_image)
            <img src="{{ asset('storage/' . $post->featured_image) }}" alt="{{ $post->title }}" 
                 style="width: 100%; height: 400px; object-fit: cover; border-radius: 0.5rem; margin-bottom: 2rem;">
        @endif

        <div class="content" style="background: #fff; padding: 2rem; border-radius: 0.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            {!! $post->content !!}
        </div>

        @if($relatedPosts->count() > 0)
            <section style="margin-top: 4rem;">
                <h2 style="font-size: 1.875rem; margin-bottom: 1.5rem;">Related Posts</h2>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 1.5rem;">
                    @foreach($relatedPosts as $relatedPost)
                        <article class="card">
                            @if($relatedPost->featured_image)
                                <img src="{{ asset('storage/' . $relatedPost->featured_image) }}" alt="{{ $relatedPost->title }}">
                            @else
                                <img src="https://via.placeholder.com/400x200?text={{ urlencode($relatedPost->title) }}" alt="{{ $relatedPost->title }}">
                            @endif
                            <div class="card-body">
                                <h3 class="card-title">
                                    <a href="{{ route('post', $relatedPost->slug) }}">{{ $relatedPost->title }}</a>
                                </h3>
                                <div class="meta">
                                    {{ $relatedPost->published_at->format('M d, Y') }}
                                </div>
                            </div>
                        </article>
                    @endforeach
                </div>
            </section>
        @endif
    </article>
@endsection
