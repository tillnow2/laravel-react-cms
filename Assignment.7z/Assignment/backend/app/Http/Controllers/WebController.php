<?php

namespace App\Http\Controllers;

use App\Models\Page;
use App\Models\Post;
use Illuminate\Http\Request;

class WebController extends Controller
{
    public function home()
    {
        $posts = Post::with(['user', 'category'])
            ->published()
            ->latest('published_at')
            ->limit(6)
            ->get();

        return view('home', compact('posts'));
    }

    public function blog(Request $request)
    {
        $query = Post::with(['user', 'category'])->published();

        if ($request->has('search')) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }

        $posts = $query->latest('published_at')->paginate(12);

        return view('blog', compact('posts'));
    }

    public function post($slug)
    {
        $post = Post::with(['user', 'category'])
            ->where('slug', $slug)
            ->published()
            ->firstOrFail();

        $relatedPosts = Post::with(['user', 'category'])
            ->where('id', '!=', $post->id)
            ->where('category_id', $post->category_id)
            ->published()
            ->limit(3)
            ->get();

        return view('post', compact('post', 'relatedPosts'));
    }

    public function page($slug)
    {
        $page = Page::where('slug', $slug)
            ->published()
            ->firstOrFail();

        return view('page', compact('page'));
    }
}
