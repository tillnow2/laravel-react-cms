<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\PostRequest;
use App\Http\Resources\PostResource;
use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function index(Request $request)
    {
        $query = Post::with(['user', 'category']);

        if ($request->has('search')) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }

        if ($request->has('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        if ($request->has('is_published')) {
            $query->where('is_published', $request->is_published);
        }

        $posts = $query->latest()->paginate($request->per_page ?? 15);

        return PostResource::collection($posts);
    }

    public function store(PostRequest $request)
    {
        $data = $request->validated();
        $data['user_id'] = $request->user()->id;

        if ($data['is_published'] && !isset($data['published_at'])) {
            $data['published_at'] = now();
        }

        $post = Post::create($data);

        return new PostResource($post->load(['user', 'category']));
    }

    public function show(Post $post)
    {
        return new PostResource($post->load(['user', 'category']));
    }

    public function update(PostRequest $request, Post $post)
    {
        $data = $request->validated();

        if ($data['is_published'] && !$post->is_published && !isset($data['published_at'])) {
            $data['published_at'] = now();
        }

        $post->update($data);

        return new PostResource($post->load(['user', 'category']));
    }

    public function destroy(Post $post)
    {
        $post->delete();

        return response()->json([
            'message' => 'Post deleted successfully',
        ]);
    }

    public function publish(Request $request, Post $post)
    {
        $post->update([
            'is_published' => $request->is_published,
            'published_at' => $request->is_published ? ($post->published_at ?? now()) : null,
        ]);

        return new PostResource($post->load(['user', 'category']));
    }
}
