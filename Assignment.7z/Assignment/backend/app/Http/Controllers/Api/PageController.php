<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\PageRequest;
use App\Http\Resources\PageResource;
use App\Models\Page;
use Illuminate\Http\Request;

class PageController extends Controller
{
    public function index(Request $request)
    {
        $query = Page::with('user');

        if ($request->has('search')) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }

        if ($request->has('is_published')) {
            $query->where('is_published', $request->is_published);
        }

        $pages = $query->latest()->paginate($request->per_page ?? 15);

        return PageResource::collection($pages);
    }

    public function store(PageRequest $request)
    {
        $data = $request->validated();
        $data['user_id'] = $request->user()->id;

        $page = Page::create($data);

        return new PageResource($page->load('user'));
    }

    public function show(Page $page)
    {
        return new PageResource($page->load('user'));
    }

    public function update(PageRequest $request, Page $page)
    {
        $page->update($request->validated());

        return new PageResource($page->load('user'));
    }

    public function destroy(Page $page)
    {
        $page->delete();

        return response()->json([
            'message' => 'Page deleted successfully',
        ]);
    }

    public function publish(Request $request, Page $page)
    {
        $page->update([
            'is_published' => $request->is_published,
        ]);

        return new PageResource($page->load('user'));
    }
}
