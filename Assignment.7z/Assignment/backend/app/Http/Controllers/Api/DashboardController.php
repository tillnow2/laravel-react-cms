<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\Page;
use App\Models\Media;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function stats(Request $request)
    {
        return response()->json([
            'total_posts' => Post::count(),
            'published_posts' => Post::where('is_published', true)->count(),
            'draft_posts' => Post::where('is_published', false)->count(),
            'total_pages' => Page::count(),
            'published_pages' => Page::where('is_published', true)->count(),
            'draft_pages' => Page::where('is_published', false)->count(),
            'total_media' => Media::count(),
            'recent_posts' => Post::with(['user', 'category'])
                ->latest()
                ->limit(5)
                ->get(),
        ]);
    }
}
