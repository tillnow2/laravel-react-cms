# Laravel CMS Backend

Laravel 12 backend API for the CMS project.

## Installation

1. Install dependencies:
```bash
composer install
```

2. Configure environment:
```bash
cp .env.example .env
php artisan key:generate
```

3. Update database credentials in `.env`

4. Run migrations and seeders:
```bash
php artisan migrate
php artisan db:seed
```

5. Create storage symlink:
```bash
php artisan storage:link
```

6. Start server:
```bash
php artisan serve
```

## API Documentation

All API endpoints are prefixed with `/api` and require authentication (except login).

### Authentication Required
Add header: `Authorization: Bearer {token}`

## Models

- **User**: Authentication and authorization
- **Post**: Blog posts with categories
- **Page**: Static pages
- **Category**: Post categorization
- **Media**: File uploads

## Default Login

- Email: admin@example.com
- Password: password
