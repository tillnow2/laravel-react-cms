# ✅ PROJECT SETUP CHECKLIST

Use this checklist to ensure everything is properly set up.

---

## 📋 Prerequisites Check

### Required Software
- [ ] PHP 8.2 or higher installed
  ```bash
  php --version
  # Should show: PHP 8.2.x or higher
  ```

- [ ] Composer installed
  ```bash
  composer --version
  # Should show: Composer version x.x.x
  ```

- [ ] Node.js 16+ and npm installed
  ```bash
  node --version  # Should show: v16.x or higher
  npm --version   # Should show: 8.x or higher
  ```

- [ ] MySQL or PostgreSQL installed and running
  ```bash
  # For MySQL
  mysql --version
  
  # Check if running (Windows)
  # Open Services and look for MySQL
  ```

- [ ] Git installed (optional)
  ```bash
  git --version
  ```

---

## 🗄️ Database Setup

- [ ] Database server is running
- [ ] Database 'laravel_cms' created
  ```sql
  CREATE DATABASE laravel_cms;
  ```
- [ ] Database credentials noted
  - Database: laravel_cms
  - Username: ___________
  - Password: ___________
  - Host: 127.0.0.1
  - Port: 3306 (MySQL) or 5432 (PostgreSQL)

---

## 🔧 Backend Setup (Laravel)

### Installation
- [ ] Navigated to backend directory
  ```bash
  cd C:\Users\16244\Documents\Assignment\backend
  ```

- [ ] Installed PHP dependencies
  ```bash
  composer install
  # Wait for completion (may take a few minutes)
  ```

### Configuration
- [ ] Copied .env.example to .env
  ```bash
  copy .env.example .env
  ```

- [ ] Updated .env file with database credentials
  ```env
  DB_CONNECTION=mysql
  DB_HOST=127.0.0.1
  DB_PORT=3306
  DB_DATABASE=laravel_cms
  DB_USERNAME=your_username
  DB_PASSWORD=your_password
  ```

- [ ] Generated application key
  ```bash
  php artisan key:generate
  # Should show: Application key set successfully.
  ```

### Database Setup
- [ ] Ran migrations
  ```bash
  php artisan migrate
  # Should show: Migration table created successfully.
  # Should show multiple "Migrating: ..." messages
  ```

- [ ] Seeded database
  ```bash
  php artisan db:seed
  # Should show: Database seeding completed successfully.
  ```

- [ ] Created storage link
  ```bash
  php artisan storage:link
  # Should show: The [public/storage] link has been connected to [storage/app/public]
  ```

### Start Server
- [ ] Started Laravel server
  ```bash
  php artisan serve
  # Should show: Server started on http://127.0.0.1:8000
  ```

- [ ] Verified backend is running
  - [ ] Open browser: http://localhost:8000
  - [ ] Should see Laravel homepage

---

## ⚛️ Frontend Setup (React)

**Open a NEW terminal window** (keep Laravel server running)

### Installation
- [ ] Navigated to admin directory
  ```bash
  cd C:\Users\16244\Documents\Assignment\admin
  ```

- [ ] Installed Node.js dependencies
  ```bash
  npm install
  # Wait for completion (may take a few minutes)
  # Ignore any warnings about optional dependencies
  ```

### Start Server
- [ ] Started React development server
  ```bash
  npm start
  # Browser should open automatically to http://localhost:3000
  ```

- [ ] Verified frontend is running
  - [ ] Login page appears
  - [ ] No console errors in browser (F12)

---

## 🔐 Authentication Test

- [ ] Can access login page at http://localhost:3000
- [ ] Login form is visible
- [ ] Attempted login with default credentials:
  - Email: admin@example.com
  - Password: password
- [ ] Login successful
- [ ] Redirected to dashboard
- [ ] Dashboard shows statistics
- [ ] Navigation sidebar visible

---

## 📝 CRUD Operations Test

### Posts
- [ ] Navigated to Posts page
- [ ] Can view posts list (or see "No posts" message)
- [ ] Clicked "+ New Post"
- [ ] Form appears correctly
- [ ] WYSIWYG editor loaded
- [ ] Created a test post:
  - Title: "Test Post"
  - Content: "This is a test"
  - Checked "Publish"
- [ ] Post created successfully
- [ ] Post appears in list
- [ ] Can edit post
- [ ] Can toggle publish status
- [ ] Can delete post (with confirmation)

### Pages
- [ ] Navigated to Pages
- [ ] Can view pages list
- [ ] Created a test page
- [ ] Page created successfully
- [ ] Can edit and delete pages

### Media
- [ ] Navigated to Media
- [ ] Can see media library
- [ ] Clicked "Upload File"
- [ ] Selected an image
- [ ] File uploaded successfully
- [ ] Can see file preview
- [ ] Can delete file

---

## 🌐 Public Website Test

- [ ] Opened http://localhost:8000 in browser
- [ ] Homepage loads correctly
- [ ] Can see hero section
- [ ] Latest posts displayed (if any)
- [ ] Clicked "Blog" link
- [ ] Blog listing page loads
- [ ] Search bar visible
- [ ] Clicked on a post
- [ ] Post detail page loads
- [ ] Content displays correctly
- [ ] Related posts shown (if available)

---

## 🔍 Browser Console Check

- [ ] Opened browser DevTools (F12)
- [ ] Checked Console tab
- [ ] No error messages (some warnings OK)
- [ ] Checked Network tab
- [ ] API requests return 200 status
- [ ] No 404 or 500 errors

---

## 📊 Dashboard Statistics

- [ ] Dashboard shows:
  - [ ] Total posts count
  - [ ] Published/draft posts
  - [ ] Total pages count
  - [ ] Media files count
  - [ ] Recent posts table

---

## 🔄 Logout Test

- [ ] Clicked "Logout" button
- [ ] Logged out successfully
- [ ] Redirected to login page
- [ ] Cannot access protected pages
- [ ] Can login again

---

## 📁 File Structure Verification

- [ ] backend/ folder exists
- [ ] admin/ folder exists
- [ ] README.md exists
- [ ] INSTALLATION.md exists
- [ ] database.sql exists
- [ ] backend/storage/app/public/ folder exists
- [ ] backend/public/storage symlink exists

---

## ⚙️ Common Issues Resolved

If you encountered issues:

- [ ] Cleared Laravel cache
  ```bash
  php artisan cache:clear
  php artisan config:clear
  php artisan route:clear
  ```

- [ ] Cleared React cache (if needed)
  ```bash
  npm cache clean --force
  ```

- [ ] Restarted both servers

- [ ] Checked database connection

- [ ] Verified CORS configuration

- [ ] Checked browser console for errors

---

## 🎯 Final Verification

### Backend Checklist
- [x] Laravel server running on port 8000
- [x] Database connected
- [x] Migrations completed
- [x] Seeders run
- [x] Storage link created
- [x] API endpoints responding
- [x] Public routes working

### Frontend Checklist
- [x] React app running on port 3000
- [x] Can login
- [x] Dashboard loads
- [x] CRUD operations work
- [x] File upload works
- [x] No console errors

### Documentation Checklist
- [x] README.md reviewed
- [x] INSTALLATION.md available
- [x] TROUBLESHOOTING.md accessible
- [x] All guides present

---

## 📸 Screenshot Checklist (for submission)

Consider taking screenshots of:
- [ ] Login page
- [ ] Dashboard
- [ ] Posts list
- [ ] Post editor
- [ ] Media library
- [ ] Public homepage
- [ ] Blog listing
- [ ] Single post page

---

## 📦 Submission Checklist

Before submitting:

- [ ] All files present
- [ ] Backend works
- [ ] Frontend works
- [ ] Documentation complete
- [ ] Default credentials work
- [ ] Database dump included
- [ ] .env.example included
- [ ] README has setup steps
- [ ] No sensitive data in code
- [ ] Code is clean and commented
- [ ] Git repository ready (if required)

---

## 🎉 Success Criteria

Your project is ready if:

✅ You can login to admin panel  
✅ You can create/edit/delete posts  
✅ You can create/edit/delete pages  
✅ You can upload and manage media  
✅ Dashboard shows correct statistics  
✅ Public website displays content  
✅ All API endpoints work  
✅ No critical errors in logs  

---

## 📞 Need Help?

If something isn't working:

1. ✅ Check [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
2. ✅ Review [INSTALLATION.md](INSTALLATION.md)
3. ✅ Check Laravel logs: `backend/storage/logs/laravel.log`
4. ✅ Check browser console (F12)
5. ✅ Verify all prerequisites are met
6. ✅ Try the "nuclear reset" in TROUBLESHOOTING.md

---

## 🎊 Congratulations!

If all items are checked, your Laravel CMS is fully functional and ready for demo/submission!

**Next Steps:**
- Customize the design
- Add more features
- Deploy to production
- Create video walkthrough

---

**Project Status:** 
- [ ] In Setup
- [ ] Testing
- [ ] Ready for Demo
- [ ] Submitted

**Date Completed:** _______________

**Notes:**
_________________________________________________
_________________________________________________
_________________________________________________
