# 🔧 TROUBLESHOOTING GUIDE

Common issues and their solutions for Laravel CMS.

---

## Installation Issues

### ❌ "composer: command not found"
**Problem:** Composer is not installed.

**Solution:**
1. Download from https://getcomposer.org/
2. Install globally
3. Restart terminal
4. Verify: `composer --version`

---

### ❌ "Your requirements could not be resolved"
**Problem:** PHP version incompatibility.

**Solution:**
```bash
# Check PHP version
php --version

# Must be 8.2 or higher
# If not, upgrade PHP
```

---

### ❌ "npm: command not found"
**Problem:** Node.js is not installed.

**Solution:**
1. Download from https://nodejs.org/
2. Install LTS version
3. Restart terminal
4. Verify: `npm --version`

---

## Database Issues

### ❌ "Access denied for user"
**Problem:** Wrong database credentials.

**Solution:**
1. Check `.env` file:
   ```env
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=laravel_cms
   DB_USERNAME=root
   DB_PASSWORD=your_actual_password
   ```
2. Verify MySQL is running
3. Test connection: `mysql -u root -p`

---

### ❌ "Unknown database 'laravel_cms'"
**Problem:** Database doesn't exist.

**Solution:**
```bash
# Login to MySQL
mysql -u root -p

# Create database
CREATE DATABASE laravel_cms;
exit;

# Run migrations again
php artisan migrate
```

---

### ❌ "Base table or view not found"
**Problem:** Migrations haven't run.

**Solution:**
```bash
php artisan migrate:fresh
php artisan db:seed
```

---

## Laravel Backend Issues

### ❌ "No application encryption key has been specified"
**Problem:** APP_KEY not generated.

**Solution:**
```bash
php artisan key:generate
```

---

### ❌ "The stream or file could not be opened"
**Problem:** Permission issues with storage.

**Solution (Linux/Mac):**
```bash
chmod -R 775 storage
chmod -R 775 bootstrap/cache
```

**Solution (Windows):**
- Right-click folders → Properties → Security
- Give full control to your user

---

### ❌ "Symfony\Component\HttpKernel\Exception\NotFoundHttpException"
**Problem:** Route not found.

**Solution:**
```bash
# Clear route cache
php artisan route:clear
php artisan route:cache

# Check routes
php artisan route:list
```

---

### ❌ "419 Page Expired" or CSRF token mismatch
**Problem:** CSRF token issue.

**Solution:**
1. API routes don't need CSRF (already configured)
2. For web routes, ensure form has `@csrf`
3. Clear config:
   ```bash
   php artisan config:clear
   php artisan cache:clear
   ```

---

## React Admin Issues

### ❌ "Failed to compile"
**Problem:** Syntax error or missing dependency.

**Solution:**
1. Check error message in terminal
2. Fix syntax error if shown
3. Or reinstall dependencies:
   ```bash
   rm -rf node_modules
   rm package-lock.json
   npm install
   ```

---

### ❌ "CORS policy" error
**Problem:** Backend not allowing requests from frontend.

**Solution:**
1. Check `backend/config/cors.php`:
   ```php
   'allowed_origins' => ['http://localhost:3000'],
   ```
2. Check `.env`:
   ```env
   SANCTUM_STATEFUL_DOMAINS=localhost,localhost:3000
   ```
3. Clear config:
   ```bash
   php artisan config:clear
   ```
4. Restart Laravel server

---

### ❌ "Network Error" or "Request failed"
**Problem:** Backend not running or wrong URL.

**Solution:**
1. Verify backend is running:
   ```bash
   php artisan serve
   # Should show: Server started on http://127.0.0.1:8000
   ```
2. Check `admin/src/services/api.js`:
   ```javascript
   baseURL: 'http://localhost:8000/api'
   ```
3. Test API manually: http://localhost:8000/api/posts

---

### ❌ "Redirect loop" or "Invalid token"
**Problem:** Authentication issue.

**Solution:**
1. Clear localStorage in browser:
   ```javascript
   // In browser console (F12)
   localStorage.clear()
   ```
2. Refresh page
3. Login again

---

### ❌ "Module not found: Can't resolve 'react-quill'"
**Problem:** Missing dependency.

**Solution:**
```bash
npm install react-quill
```

---

## File Upload Issues

### ❌ "The file could not be uploaded"
**Problem:** Storage link missing or permissions.

**Solution:**
```bash
# Create storage link
php artisan storage:link

# Check storage/app/public exists
# If not, create it manually
```

---

### ❌ "File too large"
**Problem:** PHP upload size limits.

**Solution:**
1. Edit `php.ini`:
   ```ini
   upload_max_filesize = 20M
   post_max_size = 20M
   ```
2. Restart web server

---

### ❌ "Images not showing"
**Problem:** Storage link missing.

**Solution:**
```bash
php artisan storage:link

# Verify symbolic link exists:
# public/storage -> storage/app/public
```

---

## Port Conflict Issues

### ❌ "Address already in use"
**Problem:** Port 8000 or 3000 already in use.

**Solution (Laravel):**
```bash
# Use different port
php artisan serve --port=8001
```

**Solution (React):**
```bash
# Windows
set PORT=3001 && npm start

# Linux/Mac
PORT=3001 npm start
```

---

## Authentication Issues

### ❌ "Unauthenticated" error
**Problem:** Token expired or invalid.

**Solution:**
1. Login again
2. Check token in localStorage (browser F12 → Application)
3. Verify backend session settings

---

### ❌ "These credentials do not match"
**Problem:** Wrong email/password.

**Solution:**
1. Use default credentials:
   - Email: admin@example.com
   - Password: password
2. Or reset database:
   ```bash
   php artisan migrate:fresh
   php artisan db:seed
   ```

---

## Styling Issues

### ❌ "Page looks broken" or "No styles"
**Problem:** CSS not loaded.

**Solution (React):**
1. Check browser console for errors
2. Verify CSS files imported in components
3. Clear browser cache (Ctrl+Shift+R)

**Solution (Blade):**
1. Styles are inline in layout
2. Check `resources/views/layouts/app.blade.php`

---

## Performance Issues

### ❌ "Page loading slowly"
**Problem:** No caching or optimization.

**Solution:**
```bash
# Cache configuration
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Clear all caches
php artisan optimize:clear
```

---

## Development Issues

### ❌ "Changes not reflecting"
**Problem:** Cache issues.

**Solution (Laravel):**
```bash
php artisan cache:clear
php artisan view:clear
php artisan config:clear
```

**Solution (React):**
1. Stop server (Ctrl+C)
2. Clear node cache:
   ```bash
   npm cache clean --force
   ```
3. Restart: `npm start`

---

## Database Connection Issues

### ❌ "SQLSTATE[HY000] [2002] Connection refused"
**Problem:** MySQL server not running.

**Solution (Windows):**
1. Open Services
2. Find MySQL
3. Start service

**Solution (Mac):**
```bash
brew services start mysql
```

**Solution (Linux):**
```bash
sudo systemctl start mysql
```

---

## Testing Issues

### ❌ "Cannot run migrations in test"
**Problem:** Test database not configured.

**Solution:**
1. Create test database
2. Update `phpunit.xml`:
   ```xml
   <env name="DB_DATABASE" value="laravel_cms_test"/>
   ```

---

## General Debugging Tips

### 🔍 Check Laravel Logs
```bash
# View recent errors
tail -f storage/logs/laravel.log
```

### 🔍 Enable Debug Mode
In `.env`:
```env
APP_DEBUG=true
LOG_LEVEL=debug
```

### 🔍 Check Browser Console
1. Press F12
2. Go to Console tab
3. Look for JavaScript errors

### 🔍 Network Tab
1. Press F12
2. Go to Network tab
3. Check API requests/responses
4. Look for 401, 404, 500 errors

### 🔍 React Developer Tools
1. Install React DevTools extension
2. Inspect component state
3. Check props and context

---

## Still Having Issues?

### Debugging Checklist:
- [ ] PHP version is 8.2+
- [ ] Composer is installed
- [ ] Node.js 16+ is installed
- [ ] MySQL/PostgreSQL is running
- [ ] Database exists
- [ ] .env file is configured
- [ ] Migrations have run
- [ ] Storage link exists
- [ ] Both servers are running
- [ ] Ports are not in use
- [ ] CORS is configured
- [ ] No firewall blocking

### Get More Help:
1. Check Laravel logs: `storage/logs/laravel.log`
2. Check browser console (F12)
3. Check Network tab for API errors
4. Review error messages carefully
5. Google the exact error message
6. Check Laravel docs: https://laravel.com/docs
7. Check React docs: https://react.dev

---

## Quick Reset (Nuclear Option)

If everything is broken:

```bash
# Backend
cd backend
composer install
rm -rf storage/logs/*.log
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan migrate:fresh
php artisan db:seed
php artisan storage:link

# Frontend
cd admin
rm -rf node_modules
rm package-lock.json
npm install

# Restart both servers
```

---

**Remember:** Most issues are solved by:
1. Checking logs
2. Verifying configuration
3. Clearing cache
4. Restarting servers

Good luck! 🍀
