# Laravel CMS Project

## Quick Start

This project contains a complete Laravel 12 + React CMS.

### Installation

1. **Backend (Laravel):**
   ```bash
   cd backend
   composer install
   cp .env.example .env
   # Edit .env with your database credentials
   php artisan key:generate
   php artisan migrate
   php artisan db:seed
   php artisan storage:link
   php artisan serve
   ```

2. **Admin Panel (React):**
   ```bash
   cd admin
   npm install
   npm start
   ```

3. **Login:**
   - URL: http://localhost:3000
   - Email: admin@example.com
   - Password: password

### Documentation

- [Complete README](README.md)
- [Installation Guide](INSTALLATION.md)
- [Video Walkthrough Script](VIDEO_WALKTHROUGH.md)
- [Project Summary](PROJECT_SUMMARY.md)

### Structure

```
Assignment/
├── backend/        # Laravel 12 API & Public Website
├── admin/          # React 18 Admin Panel
├── README.md       # Main documentation
├── INSTALLATION.md # Setup guide
└── database.sql    # SQL dump
```

### Default Credentials

- **Admin:** admin@example.com / password
- **User:** user@example.com / password

Enjoy! 🚀
